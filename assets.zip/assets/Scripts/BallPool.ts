import { _decorator, Component, Node, Prefab,sys, screen, instantiate, UITransform, Label, EventTouch, Sprite,color,Vec3, randomRangeInt, EditBox, SpriteFrame } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('BallPool')
export class BallPool extends Component {
    @property(Prefab)
    boxprefab: Prefab

    @property(Node)
    Ballpool: Node

    @property(Node)
    Selected:Node

    @property(Prefab)
    labelPrefab:Prefab

    @property(EditBox)
    editbox:EditBox

    @property(Node)
    Picktext:Node

    @property(SpriteFrame)
    selectedsprite:SpriteFrame

    @property(SpriteFrame)
    resultsprite:SpriteFrame

    @property(SpriteFrame)
    initSprite:SpriteFrame

    @property(SpriteFrame)
    wrongSprite:SpriteFrame

    @property(Label)
    amount:Label

    @property(Prefab)
    increasprefab:Prefab
    
    @property(Node)
    topnode:Node

    createball
    selectionball=new Array
    selectedBall
    percent
    selectedheight=290
    selectedwidth=1310
    multipoints=new Array
    valuesArr: Array<number> =new Array
    small: number = 6
    columns: number = this.small
    rows: number = 6
    height: number
    width: number
    u: number = 1
    v: number = 1
    child
    percentchild
    value
    str
    randomint
    randomintarr=new Array
    randomgeneration:boolean=false
    Allpoints=new Array
    resultpoints=new Array
    correctcount=0
    payoutchildren
    betClicked:boolean=false
    noOfSelection=new Array
    incdec=new Array
    two=new Array
    payoutcheck:boolean=false
    increasedamount
    anssprite=0
    gotananswer:boolean=false
    randompointarray=new Array
    resultselectionpoints=new Array

    onLoad() {
      console.log("Build Keno 3");
        this.multipoints=[
          3.49,
          1.50,4.92,
          1.00,2.30,8.20,
          0.50,1.82,4.20,21.00,
          0.00,1.10,3.75,15.00,35.00,
          0.00,0.50,2.90,7.60,18.00,55.00,
          0.00,0.25,2.30,4.10,10.00,31.00,60.00,
          0.00,0.00,1.40,2.80,11.40,28.00,40.00,70.00,
          0.00,0.00,1.00,2.20,6.10,17.00,25.00,55.00,85.00,
          0.00,0.00,1.00,1.50,3.30,10.20,25.00,40.00,75.00,100.00
        ]
        this.incdec=[0.10,0.20,0.30,0.40,0.50,0.60,0.70,0.80,0.90,1.00,2.00,4.00,10.00,20.00,50.00,75.00,100.00]
        this.Allpoints=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36]
        this.noOfSelection=[[0,0],[1,0,0,0,0,0,0,0,0,0,1],[2,0,0,0,0,0,0,0,0,1,2],[3,0,0,0,0,0,0,1,1,2,3],
        [4,0,0,1,1,1,1,0,0,1,0,0,0,1,1,3,1,0,0,1,0,0,1,1,1,0,1,0,0,1,0,0,1,2,1,1,0,0,1,0,1,0,1,0,1,0,0,1,1,0,0,4],
        [5,0,0,1,2,1,0,1,0,0,1,0,0,1,0,1,3,1,0,0,1,0,0,1,2,1,0,1,0,0,1,0,0,1,2,1,0,1,0,0,4,1,0,1,1,0,0,1,1,0,0,5],
        [6,0,0,1,2,1,1,0,0,1,0,1,0,1,1,3,1,0,0,1,0,0,1,2,1,4,1,0,0,1,0,0,1,2,1,0,1,1,0,1,0,1,1,0,1,2,1,0,5,0,0,6],
        [7,0,0,1,2,1,1,0,0,1,0,1,0,1,1,3,1,0,0,1,0,1,2,1,4,1,0,0,1,0,0,1,2,1,0,1,1,0,1,0,1,1,0,1,2,1,5,0,1,0,6,7],
        [8,0,2,1,2,1,1,0,0,1,0,1,0,1,1,3,1,0,0,1,0,1,2,1,4,1,0,0,1,0,0,1,2,1,0,1,1,0,1,0,1,1,0,1,2,1,5,0,2,2,,1,
          0,2,1,2,1,1,0,0,1,0,1,0,1,1,1,1,0,0,1,0,1,2,1,1,1,0,0,1,0,0,1,2,1,0,1,1,0,1,0,1,1,0,1,2,1,2,0,6,7,8],
        [9,0,2,1,2,1,1,2,0,1,0,1,0,1,1,3,1,0,2,1,0,1,2,1,4,1,0,0,1,0,0,1,1,0,1,1,0,1,0,1,1,0,1,2,1,2,2,2,2,2,0,2,
          0,2,1,2,1,1,2,0,1,0,1,0,1,1,1,1,0,2,1,0,1,2,1,2,1,0,0,1,0,0,1,1,0,1,1,0,1,0,1,1,0,1,2,1,5,0,6,7,8,9],
        [10,0,2,1,2,1,1,0,0,1,0,1,2,1,1,3,1,0,1,1,2,1,2,1,4,1,1,0,1,0,1,2,1,2,1,1,0,1,1,1,0,1,2,1,0,1,2,1,0,2,1,2,
          0,2,1,2,1,1,0,3,1,0,1,2,1,1,3,1,0,1,1,2,1,2,1,1,1,1,3,1,0,1,2,1,2,1,1,0,1,1,1,0,1,2,1,0,5,6,7,8,9,10]]
        console.log("mi",this.multipoints[9]);
        this.str = Number(this.editbox.getComponentInChildren(Label).string)
        this.height = this.Ballpool.getComponent(UITransform).height - 250+10
        this.width = this.Ballpool.getComponent(UITransform).width / 3-60
        this.child=this.Ballpool.children
        this.percentchild=this.Selected.children
        console.log(this.noOfSelection[4].length);
        if(sys.localStorage.getItem("TotalAmount")==null || sys.localStorage.getItem("TotalAmount")=="0" || sys.localStorage.getItem("TotalAmount")=="NaN" ){ 
          sys.localStorage.setItem("TotalAmount",String(Number(3000.00).toFixed(2)))
          this.amount.getComponent(Label).string=3000.00+""
        }else{
          this.amount.getComponent(Label).string= String(sys.localStorage.getItem("TotalAmount"))

        }
        this.Creatball() 
    }

    Creatball() {
        for (let i = 0; i < this.rows; i++) {
            for (let j = 0; j < this.small; j++) {
                if (j > 0) {
                    this.width = this.width + 120
                }
                this.boxprefab.data.getChildByName("Label").getComponent(Label).string = this.u
                // console.log(this.u,"u value");    
                this.createball = instantiate(this.boxprefab)
                // console.log(this.createball.getChildByName("Label").getComponent(Label).string);
                this.createball.getChildByName("Label").getComponent(Label).string=this.u
                this.createball.on(Node.EventType.TOUCH_START,this.touchstart,this)
                this.u++
                this.Ballpool.addChild(this.createball)
                this.createball.setPosition(this.width, this.height, 0)
                if (j == 5) {
                    this.height = this.height - 103
                    this.width = this.Ballpool.getComponent(UITransform).width / 3-60
                }
            }
        } 
    }

    maxtoch(){
      for(let j=10;j<=36;j++){
        // this.valuesArr[j].off(Node.EventType.TOUCH_START)
        this.Ballpool.children[j].off(Node.EventType.TOUCH_START)
    }
    }

    sorting(){
      this.betClicked=true
        for (let m = 0; m < this.valuesArr.length; m++) {
            for (let n = m; n < 36; n++) {
              if (this.valuesArr[m] == this.Allpoints[n]) {
                let temp = this.Allpoints[m];
                this.Allpoints[m] = this.Allpoints[n];
                this.Allpoints[n] = temp;
                break;
              }
            }
          }
    }

    touchoff(){
      for(let i=0;i<36;i++){
      this.Ballpool.children[i].off(Node.EventType.TOUCH_START)
      }
    }
    touchon(){
      for(let i=0;i<36;i++){
        this.Ballpool.children[i].on(Node.EventType.TOUCH_START,this.touchstart,this)
        }
    }
    
    touchstart(event:EventTouch){
      if(this.betClicked==true){
       this.clear()
      }
        this.Picktext.active=false
    let curball = event.target as Node;
    this.selectionball.push(curball);
    this.value = curball.getChildByName("Label").getComponent(Label).string;
  //  if(this.v>10){
  //   console.log("enterd");
  //   // this.sorting()
  //   // this.maxtoch()

  //   if(this.valuesArr.indexOf(this.value,0)){
  //     console.log("has");
  //     curball.getComponent(Sprite).spriteFrame=this.initSprite
  //     this.removevalue(this.value)
  //     this.v--;
  //   }
  //  }
    if (this.v <= 10) {
      if (this.v == 1) {
        console.log("fsdf", this.valuesArr);
        this.valuesArr.push(this.value);
        curball.getComponent(Sprite).spriteFrame=this.selectedsprite
        this.Selected.removeChild(this.percentchild[this.percentchild.length - 1]);
        this.selected();
      } else {

        for(let j=0;j<this.valuesArr.length;j++){
            console.log("valArr", this.valuesArr[j]);
          console.log("curr", this.value);
            if (this.valuesArr[j] == this.value ) {
                console.log("SS");
                curball.getComponent(Sprite).spriteFrame=this.initSprite
                this.Selected.removeChild(this.percentchild[this.percentchild.length - 1]);
                console.log(this.valuesArr,"Before pop");
                this.removevalue(this.value)
                if(this.v>1){
                  this.payoutcheck=true
                this.v--;
                this.selectedheight = this.selectedheight - 65;
                this.payoutmultiple()
                console.log(this.valuesArr);
                break
                }
            }
                else if(this.valuesArr[j] != this.value && j==this.valuesArr.length-1){
                    console.log("Enterd");
                    this.valuesArr.push(this.value);
                    curball.getComponent(Sprite).spriteFrame=this.selectedsprite
                    this.selected();
                    j=0
                    console.log(this.valuesArr);
                    break;
                }  
        }
      }
    }
    }

    removevalue(n){
            for(let i=0;i<this.valuesArr.length;i++){
              if(n==this.valuesArr[i]){
                for(let j=i;j<this.valuesArr.length-1;j++){
                  this.valuesArr[j]=this.valuesArr[j+1]
                }
              }
            }
            this.valuesArr.pop()
    }

    payoutmultiple(){
      console.log();
      console.log(this.v);
      if(this.payoutcheck){
        this.v--
        // this.payoutcheck=false
      }
      // this.v--
      switch(this.v){
        case 1:
          // console.log("ghfdjhksf");
          this.payoutchildren[0].getChildByName("multi").getComponent(Label).string = this.multipoints[0].toFixed(2)+"x"
          break
        case 2:
        console.log(this.v,"v");
          for(let n=0;n<this.v;n++){  
            this.payoutchildren[n].getChildByName("multi").getComponent(Label).string = this.multipoints[n+1].toFixed(2)+"x"
          }
          break
        case 3:
            console.log(this.v,"v");
            for(let n=0;n<this.v;n++){
              this.payoutchildren[n].getChildByName("multi").getComponent(Label).string = this.multipoints[n+3].toFixed(2)+"x"
            }
            break
        case 4:
              console.log(this.v,"v");
              for(let n=0;n<this.v;n++){
                this.payoutchildren[n].getChildByName("multi").getComponent(Label).string = this.multipoints[n+6].toFixed(2)+"x"
              }
              break
        case 5:
              console.log(this.v,"v");
              for(let n=0;n<this.v;n++){
                this.payoutchildren[n].getChildByName("multi").getComponent(Label).string = this.multipoints[n+10].toFixed(2)+"x"
              }
              break
        case 6:
                console.log(this.v,"v");
                for(let n=0;n<this.v;n++){
                  this.payoutchildren[n].getChildByName("multi").getComponent(Label).string = this.multipoints[n+15].toFixed(2)+"x"
                }
                break
        case 7:
                  console.log(this.v,"v");
                  for(let n=0;n<this.v;n++){
                    this.payoutchildren[n].getChildByName("multi").getComponent(Label).string = this.multipoints[n+21].toFixed(2)+"x"
                  }
                  break
        case 8:
                    console.log(this.v,"v");
                    for(let n=0;n<this.v;n++){
                      this.payoutchildren[n].getChildByName("multi").getComponent(Label).string = this.multipoints[n+28].toFixed(2)+"x"
                    }
                    break
        case 9:
                      console.log(this.v,"v");
                      for(let n=0;n<this.v;n++){
                        this.payoutchildren[n].getChildByName("multi").getComponent(Label).string = this.multipoints[n+36].toFixed(2)+"x"
                      }
                      break
        case 10:
                        console.log(this.v,"v");
                        for(let n=0;n<this.v;n++){
                          this.payoutchildren[n].getChildByName("multi").getComponent(Label).string = this.multipoints[n+45].toFixed(2)+"x"
                        }
                        break
      }
      if(this.payoutcheck){
        this.v++
        this.payoutcheck=false
      }

    }

    selected(){
      if(this.v<=10){
        this.labelPrefab.data.getChildByName("Label").getComponent(Label).string = this.v + ""
        this.selectedBall=instantiate(this.labelPrefab)
        this.Selected.addChild(this.selectedBall)
        this.payoutchildren=this.Selected.children
        console.log(this.payoutchildren,"jjjjjj");
        
        this.selectedBall.setPosition(this.selectedwidth,this.selectedheight,0)
        this.selectedBall.getChildByName("Label").getComponent(Label).string=this.v
        this.payoutmultiple()        
        this.v++
       
        this.selectedheight=this.selectedheight+65
        console.log(this.percentchild);
        }
        this.payoutchildren=this.Selected.children
    }

    clear(){
        for (let m = 0; m < 36; m++) {
            this.child[m].getComponent(Sprite).spriteFrame=this.initSprite
            this.Ballpool.children[m].on(Node.EventType.TOUCH_START,this.touchstart,this)
          }
          for(let n=0;n<10;n++){
            this.randomintarr.pop()
            this.resultpoints.pop()
            this.valuesArr.pop()
          }
          for(let i=0;i<this.randompointarray.length;i++){
            this.randompointarray.pop()
          }
          this.Selected.removeAllChildren();
          this.selectedheight = 290;
          this.v = 1;
          this.Picktext.active=true
          this.correctcount=0
          this.randomgeneration=false
          this.betClicked=false
          this.anssprite=0
          this.gotananswer=false
          this.increasedamount=0
          
          console.log(this.randomintarr,"random");
          console.log(this.resultpoints,"result");
          console.log(this.valuesArr,"valuearr"); 
        }
    random(){
      if(this.betClicked==true){
        this.clear()
      }
      if(this.randomgeneration==true){
        this.clear()
      }
      if(this.randomgeneration==false){
        this.randomgeneration=true
        this.Picktext.active=false
      if(this.valuesArr.length>0){
        console.log("Entertd");
        this.Selected.removeAllChildren()
        this.selectedheight=290
        for(let i=0;i<36;i++){
          this.child[i].getComponent(Sprite).spriteFrame=this.initSprite
        }
        for(let i=0;i<this.valuesArr.length;i++){
          this.valuesArr.pop()
        }
      }
      console.log(this.valuesArr);
      
        for (let j = 0; j < 10; j++) {
            // console.log(j);
            
            if (j == 0) {
              this.randomint = randomRangeInt(1, 36);
              this.randomintarr.push(this.randomint);
            //   console.log(this.randomint,"inside ");
              
            } else {
              this.randomint = randomRangeInt(1, 36);
              for (let k = 0; k < this.randomintarr.length; k++) {           
                if (this.randomint != this.randomintarr[k]) {
                  if (k == this.randomintarr.length - 1) {
                    this.randomintarr.push(this.randomint);
                  } 
                } else {
                  j--;
                  break;
                }
              }
            }
            if (this.randomintarr.length == 10) {
              j = 0;
              
              break;
            }
          }
        
          this.randomselection(this.randomintarr);
        }
    }

    randomselection(randompos){
      this.v=1
      for(let m=0;m<randompos.length;m++){
          this.child[randompos[m]].getComponent(Sprite).spriteFrame=this.selectedsprite
          let randomball=instantiate(this.labelPrefab)
          randomball.getChildByName("Label").getComponent(Label).string=this.v+""
          randomball.getChildByName("multi").getComponent(Label).string = this.multipoints[m+45].toFixed(2)+"x"
          this.v++
          this.Selected.addChild(randomball)
          randomball.setPosition(this.selectedwidth,this.selectedheight,0)
          this.selectedheight=this.selectedheight+65
      }
      this.valuesArr= randompos
    //  console.log(randompos,"oeuuduijuh");
     for(let i=0;i<10;i++){
      randompos[i]++
    }
      this.payoutchildren=this.Selected.children
  }

    generaterandomresultpoints(){
      let j=10
      for(let i=0;i<26;i++){
        this.resultselectionpoints[i]=this.Allpoints[j]
        j++
      }
      console.log(this.resultselectionpoints,"hi");
      let no=27
      let rand=randomRangeInt(0,no)
      console.log(rand,"ss");
      
      for(let j=0;j<10;j++){
        this.resultpoints[j]=this.resultselectionpoints[rand]
        this.removenumber(this.resultselectionpoints[rand])
        no--
        rand=randomRangeInt(0,no)
        console.log(rand,"sss");
        
      }
      console.log(this.resultselectionpoints,"hi");
    }

    generate(){
      let j=10
      for(let i=0;i<26;i++){
        this.resultselectionpoints[i]=this.Allpoints[j]
        j++
      }
      let n1=new Array
      let n2=new Array
      let n3=new Array
      let n4=new Array
      let no=0
      for(let i=10;i<15;i++){
        n1[no]=this.Allpoints[i]
      }
      for(let i=15;i<20;i++){
        n1[no]=this.Allpoints[i]
      }
      for(let i=20;i<25;i++){
        n1[no]=this.Allpoints[i]
      }
      for(let i=25;i<30;i++){
        n1[no]=this.Allpoints[i]
      }
      for(let i=10;i<35;i++){
        n1[no]=this.Allpoints[i]
      }
    }

    removenumber(n){
      for(let i=0;i<this.resultselectionpoints.length-1;i++){
        if(n==this.resultselectionpoints[i]){
          for(let j=i;j<27;j++){
           this.resultselectionpoints[j]=this.resultselectionpoints[j+1]
          }
        }
      }
      this.resultselectionpoints.pop()
      for(let i=0;i<10;i++){
        this.resultpoints[i]= this.resultselectionpoints[i]
      }
    }

    bet(){
      if(this.valuesArr.length!=0 && this.betClicked==false){
        this.betClicked=true
        for (let m = 0; m < this.valuesArr.length; m++) {
            for (let n = m; n < 36; n++) {
              if (this.valuesArr[m] == this.Allpoints[n]) {
                let temp = this.Allpoints[m];
                this.Allpoints[m] = this.Allpoints[n];
                this.Allpoints[n] = temp;
                break;
              }
            }
          }
          // let gap=randomRangeInt(10,14)
          // console.log(gap,"gap value");
          this.generaterandomresultpoints()
          // this.randompointarray.push(gap)
          // for (let l = 0; l < 10; l++) {
          //   this.resultpoints[l] = this.Allpoints[gap];
          //   if(l%2==0){
          //     let rand=randomRangeInt(1,3)
          //   gap=gap+rand
          //   }
          //   else
          //   gap=gap+3
                
          //   }    
              // console.log(gap,"gap inside for");  
          }
          console.log();
          
      console.log(this.valuesArr,"value arr");
      console.log(this.Allpoints,"All points arr");
          let getnoOfSelection=this.valuesArr.length
          let select=this.noOfSelection[getnoOfSelection]
          let s1=select[0]
          let s2
          if(s1==1 || s1==2 || s1==3){
            let rand=randomRangeInt(1,11)
            console.log(rand,"random value generated");
             s2=select[rand]
             console.log(s2);
          }
          else if(s1==4 || s1==5 || s1==6 ||s1==7){
              let rand=randomRangeInt(1,52)
              console.log(rand,"random value generated")
              s2=select[rand]
          }
          else if(s1==8 ||s1==9 || s1==10){
            let rand=randomRangeInt(1,102)
              console.log(rand,"random value generated")
              s2=select[rand]
          }
        
       
          console.log("s1",s1);
          console.log(s2,"s2");
          
          console.log(this.resultpoints,"result array");
          
     
            if(s2==1)
            this.resultpoints[0]=this.valuesArr[this.valuesArr.length-1];
           
          else{
            if(s2==0){

            }
            // else if(s2>=2 || s2<=10) {
            //   let rand
            // }
            else if(s2>=2 || s2<=10){
              let rand
              if(s2==5 || s2==6 || s2==7){
                 rand=0
                 console.log(rand,"SKLH");
              }
              else if(s2==10 || s2==9 || s2==8){
                 rand=0
                 console.log(rand,"KSU");
              }else if(s2==2 || s2==3 || s2==4){
               
                rand=0
                console.log(rand,"kaj");
                
              }
              for(let i=rand;i<s2+rand;i++){
                this.resultpoints[i]=this.valuesArr[i];
              }
            }
          }
          console.log(this.Allpoints);
          console.log("result", this.resultpoints);
          console.log(this.valuesArr);
      
          for (let k = 0; k < this.resultpoints.length; k++) {
            this.child[this.resultpoints[k] - 1].getComponent(Sprite).spriteFrame =this.wrongSprite
            // this.payoutchildren[k].setScale(0.7,0.7,1)
          }
    
          for (let q = 0; q < this.resultpoints.length; q++) {
            for (let n = 0; n < this.resultpoints.length; n++) {
              if (this.resultpoints[q] == this.valuesArr[n]) {           
                this.payoutchildren[this.correctcount].getComponent(Sprite).spriteFrame=this.resultsprite
                this.payoutchildren[this.correctcount].getComponent(UITransform).width=62
                this.payoutchildren[this.correctcount].getComponent(UITransform).height=61
                this.correctcount++
                this.child[this.resultpoints[q] - 1].getComponent(Sprite).spriteFrame=this.resultsprite
                break;
              }
            }
          }

          let betvalue=Number(this.editbox.getComponentInChildren(Label).string)
          let amount=Number(this.amount.getComponent(Label).string)
          console.log(this.anssprite,"answersprite 1");
          
          // this.anssprite=0
          this.amount.getComponent(Label).string=String((amount-betvalue).toFixed(2))
          setTimeout(()=>{
          for(let n=0;n<this.valuesArr.length;n++){
            if(this.payoutchildren[n].getComponent(Sprite).spriteFrame==this.resultsprite){
              this.gotananswer=true
              this.anssprite++
            }
            
          }
          // console.log(this.anssprite,"ahgdkjadgh");
          
          if(this.gotananswer==false){
            this.anssprite=0
          }
          // console.log(this.anssprite,"ahgdkjadgh");
          switch(this.valuesArr.length){
            case 1:
              if( this.payoutchildren[0].getComponent(Sprite).spriteFrame==this.resultsprite){
              this.amount.getComponent(Label).string= String((((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[0]))+ Number(this.amount.getComponent(Label).string)).toFixed(2))
              this.increasedamount=Number((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[0]).toFixed(2))
              }else
              this.increasedamount=0
              break
            case 2:
              if( this.payoutchildren[0].getComponent(Sprite).spriteFrame==this.resultsprite){
                this.amount.getComponent(Label).string= String((((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[this.anssprite+1]))+ Number(this.amount.getComponent(Label).string)).toFixed(2))
                this.increasedamount=Number((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[this.anssprite+1]).toFixed(2))
              }else
              this.increasedamount=0
              break
            case 3:
              if( this.payoutchildren[0].getComponent(Sprite).spriteFrame==this.resultsprite){
                this.amount.getComponent(Label).string= String((((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[this.anssprite+3]))+ Number(this.amount.getComponent(Label).string)).toFixed(2))
                this.increasedamount=Number((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[this.anssprite+2]).toFixed(2))
               } else
              this.increasedamount=0
              break
            case 4:
              if( this.payoutchildren[0].getComponent(Sprite).spriteFrame==this.resultsprite){
                this.amount.getComponent(Label).string= String((((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[5+this.anssprite]))+ Number(this.amount.getComponent(Label).string)).toFixed(2))
                this.increasedamount=Number((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[5+this.anssprite]).toFixed(2))
              }else
              this.increasedamount=0
              break
            case 5:
              if( this.payoutchildren[0].getComponent(Sprite).spriteFrame==this.resultsprite){
                this.amount.getComponent(Label).string= String((((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[9+this.anssprite]))+ Number(this.amount.getComponent(Label).string)).toFixed(2))
                this.increasedamount=Number((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[9+this.anssprite]).toFixed(2))
              }else
                this.increasedamount=0
              break
            case 6:
              if( this.payoutchildren[0].getComponent(Sprite).spriteFrame==this.resultsprite){
              this.amount.getComponent(Label).string= String((((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[14+this.anssprite]))+ Number(this.amount.getComponent(Label).string)).toFixed(2))
              this.increasedamount=Number((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[14+this.anssprite]).toFixed(2))
              }else
              this.increasedamount=0
              break
            case 7:
              if( this.payoutchildren[0].getComponent(Sprite).spriteFrame==this.resultsprite){
              this.amount.getComponent(Label).string= String((((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[20+this.anssprite]))+ Number(this.amount.getComponent(Label).string)).toFixed(2))
              this.increasedamount=Number((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[20+this.anssprite]).toFixed(2))
              }else
              this.increasedamount=0
              break
            case 8:
              if( this.payoutchildren[0].getComponent(Sprite).spriteFrame==this.resultsprite){
              this.amount.getComponent(Label).string= String((((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[27+this.anssprite]))+ Number(this.amount.getComponent(Label).string)).toFixed(2))
              this.increasedamount=Number((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[27+this.anssprite]).toFixed(2))
            }else
              this.increasedamount=0
              break
            case 9:
              if( this.payoutchildren[0].getComponent(Sprite).spriteFrame==this.resultsprite){
              this.amount.getComponent(Label).string= String((((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[35+this.anssprite]))+ Number(this.amount.getComponent(Label).string)).toFixed(2))
              this.increasedamount=Number((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[35+this.anssprite]).toFixed(2))
              }else
              this.increasedamount=0
              break
            case 10:
              if( this.payoutchildren[0].getComponent(Sprite).spriteFrame==this.resultsprite){
              this.amount.getComponent(Label).string= String((((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[44+this.anssprite]))+ Number(this.amount.getComponent(Label).string)).toFixed(2))
              this.increasedamount=Number((Number(this.editbox.getComponentInChildren(Label).string)* this.multipoints[44+this.anssprite]).toFixed(2))
              }else
              this.increasedamount=0
              break  
          } 
          sys.localStorage.setItem("TotalAmount", this.amount.getComponent(Label).string)   
        //  console.log(typeof(this.increasedamount),"jhfg")
         if(this.increasedamount>0){     
          if(typeof(this.increasedamount)){
          let createlabel=instantiate(this.increasprefab)
          createlabel.getChildByName("Label").getComponent(Label).string="+"+this.increasedamount+"USD"
          // createlabel.getComponent(Label).string="+"+this.increasedamount
          this.topnode.addChild(createlabel)
          createlabel.setPosition(545,0,0)
          setTimeout(()=>{
            this.topnode.removeChild(createlabel)
          },1000)
        }
          }
          console.log(amount,"amount");  
          console.log(betvalue,"bet value");
      },1000)
        }

    
  

    increase() {
      this.str = Number(this.editbox.getComponentInChildren(Label).string)
      console.log(this.str);
      for(let n=0;n<this.incdec.length;n++){
        if(this.str!<this.incdec[n]){
          console.log("fdghf",n);
          this.editbox.getComponentInChildren(Label).string = this.incdec[n]
          break
          }
      }
      }
    
      decrease() {
        this.str = Number(this.editbox.getComponentInChildren(Label).string)
        for(let n=this.incdec.length;n>0;n--){
          if(this.str==this.incdec[n]){
            console.log("fdghf",n);
            this.editbox.getComponentInChildren(Label).string = this.incdec[n-1]
            break
            }
        }
      }
    }

        // generaterandomresultpoints(){
    //   let gap=randomRangeInt(10,36)
    //   this.randompointarray.push(gap)
    //   for(let i=0;i<10;i++){
    //     gap=randomRangeInt(10,36)
    //     if(gap!=this.randompointarray[i]){
    //       if(i==this.randompointarray.length-1){

    //       }
    //     }
    //     this.randompointarray.push(gap)
    //   }
    // }