import { _decorator, Component, Node, Prefab, instantiate, UITransform, Label, EditBox, EventTouch } from 'cc';
import { BallPool } from './BallPool';
const { ccclass, property } = _decorator;

@ccclass('keyboard')
export class keyboard extends Component {
   
    @property(Prefab)
    buttonprefab:Prefab

    @property(Node)
    keyboard:Node

    @property(EditBox)
    input:EditBox

    @property(BallPool)
    ballPool:BallPool

    height=300
    width=70
    i=1
    k=0
    showing:boolean=false
    count=1
    child

    start(){
        this.input.getComponentInChildren(Label).string="0.10"
       this.node.active=false
    }
    show(){
        if(this.showing==false){
            this.showing=true
        this.node.active=true
        // this.input.getComponentInChildren(Label).string=""
        this.input.getComponentInChildren(Label).string="0.10"
        for(let i=0;i<3;i++){
            for(let j=0;j<3;j++){
                let button=instantiate(this.buttonprefab)
                button.on(Node.EventType.TOUCH_START,this.OnAmtbtnClicked,this)
                button.getComponentInChildren(Label).string=this.i+""
                this.i++
                button.getComponent(UITransform).width=90
                this.keyboard.addChild(button)
                button.setPosition(this.width,this.height,0)
                this.width=this.width+100
            }
            this.child=this.keyboard.children
            console.log("children",this.child);
            this.height=this.height-70
            this.width=70
        }
        this.input.getComponentInChildren(Label).string="0.10"
    }
    }
    hide(){
      this.showing=false
      this.height=300
      this.width=70
      this.i=1
      this.count=1
      for(this.k=0;this.k<9;this.k++){
        console.log("deleting");
       this.child.pop()
      }
      if(Number(this.input.getComponentInChildren(Label).string)>100){
        this.input.getComponentInChildren(Label).string=100+""
      }
      this.k=0
        this.node.active=false
    }
    OnAmtbtnClicked(event:EventTouch){
        if(this.count==1){
        let curnode = event.target as Node
        let value=curnode.getChildByName("Label").getComponent(Label).string
        this.input.getComponentInChildren(Label).string=value
        this.count++
    }else{
        let curnode = event.target as Node
        let value=curnode.getChildByName("Label").getComponent(Label).string
        this.input.getComponentInChildren(Label).string= this.input.getComponentInChildren(Label).string+value
        this.count++
    }
}
    onBtnClick(){
        if(this.count==1){
            console.log(this.keyboard.getChildByName("Button").getChildByName("Label").getComponent(Label).string);
            
           let value=this.keyboard.getChildByName("Button").getChildByName("Label").getComponent(Label).string
           this.input.getComponentInChildren(Label).string=value
           this.count++
        }
        else{
            let value=this.keyboard.getChildByName("Button").getChildByName("Label").getComponent(Label).string
            this.input.getComponentInChildren(Label).string=this.input.getComponentInChildren(Label).string+value
            this.count++
        }
    }
    onBtnClickzero(){
        if(this.count==1){
            console.log(this.keyboard.getChildByName("ZeroButton").getChildByName("Label").getComponent(Label).string);
            
           let value=this.keyboard.getChildByName("ZeroButton").getChildByName("Label").getComponent(Label).string
           this.input.getComponentInChildren(Label).string=value
           this.count++
        }
        else{
            let value=this.keyboard.getChildByName("ZeroButton").getChildByName("Label").getComponent(Label).string
            this.input.getComponentInChildren(Label).string=this.input.getComponentInChildren(Label).string+value
            this.count++
        }
    }

    deletButton(){
        // console.log(this.count,"count");
        // let value= this.input.getComponentInChildren(Label).string
        // let newvalue=Number(value)-Number(value)%10+""
        // this.input.getComponentInChildren(Label).string=Number(newvalue)/10+""
        // this.count--
        this.input.getComponentInChildren(Label).string="0"
        this.count=1
    }
}

