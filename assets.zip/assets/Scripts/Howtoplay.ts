import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('Howtoplay')
export class Howtoplay extends Component {
    @property(Node)
    tutorial: Node

    start() {
        this.node.active = false
    }
    show() {
        this.node.active = true
    }
    close(){
        this.node.active = false
    }
}

